/* Logan Sines
 * CSC-289-0B01
 * Java Medical Project
 * 3-12-2022
 */

package javamedical;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.Parent;
import javafx.scene.Node;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javamedical.objects.Appointment;
import javamedical.objects.Assets;
import javamedical.objects.Patient;
import javamedical.objects.Prescription;

public class PatientHomepageController implements Initializable 
{
    private Stage stage;
    private Scene scene;
    private Parent root;
    
    //<editor-fold defaultstate="collapsed" desc="FXML">
    @FXML private TableView<Appointment> appointmentsTable;
    @FXML private TableColumn<Appointment, String> dateColumn;
    @FXML private TableColumn<Appointment, String> timeColumn;
    @FXML private TableColumn<Appointment, String> timeStartColumn;
    @FXML private TableColumn<Appointment, String> timeEndColumn;
    @FXML private TableColumn<Appointment, String> doctorNameColumn;
    @FXML private TableColumn<Appointment, String> notesColumn;
    @FXML private TableView<Prescription>  prescriptionsTable;
    @FXML private TableColumn<Prescription, String> prescriptionNameColumn;
    @FXML private TableColumn<Prescription, String> datePrescribedColumn;
    @FXML private TableColumn<Prescription, String> doctorsNotesColumn;
    //</editor-fold>
    
    ObservableList<Appointment> list = FXCollections.observableArrayList(
                new Appointment("101", "98423", "54796", "12:30:00", "13:45:00", "01/05/2022", "Null"),
                new Appointment("262", "98423", "12587", "13:45:00", "15:00:00", "02/10/2022", "NULL"),
                new Appointment("324", "4623", "25886", "11:00:00", "12:45:00", "02/15/2022", "NULL"),
                new Appointment("463", "34167", "12587", "09:15:00", "10:30:00", "03/02/2022", "NULL"),
                new Appointment("595", "13496", "25886", "14:10:00", "15:10:00", "04/06/2020", "NULL"),
                new Appointment("648", "46238", "76467", "08:45:00", "09:15:00", "04/22/2022", "NULL"),
                new Appointment("696", "21458", "54796", "08:00:00", "09:00:00", "06/04/2022", "NULL"),
                new Appointment("709", "13496", "25886", "10:45:00", "12:00:00", "06/06/2022", "NULL"),
                new Appointment("810", "21458", "54796", "15:30:00", "16:45:00", "7/06/2022", "NULL"),
                new Appointment("919", "56248", "12587", "07:00:00", "00:00:00", "08/25/2022", "NULL")
         );
    
    ObservableList<Prescription> list2 = FXCollections.observableArrayList(
                new Prescription("J0702", "Betamethasone Acetate", "Celestone Soluspan", "Injection, Betamethasone acetate 3 mg", "34167", "12587", "Zack", "Fair", "Medcap", "02/14/2017", 3, "NULL"),
                new Prescription("J9015", "Aledeslekin", "Proleukin", "Injection, aldesleukin, per single-use vial", "21458", "76467", "Regina", "Hudson", "WalMart", "03/06/2022", 1, "NULL"),
                new Prescription("J9035", "Bevacizumab", "Avastin", "Injection, Bevaciazumab 10 mg", "46238", "25886", "Luigi", "Mario", "CVS", "05/09/2022", 4, "NULL"),
                new Prescription("J9040", "Bleomycin", "Blenoxane", "Injection, Bleomycin Sulfate, 15units", "98423", "54796", "Sky", "Savage", "Walgreens", "01/05/2022", 2, "NULL"),
                new Prescription("J9045", "Carboplatin", "Paraplatin", "Injection, carboplatin, 50 mg", "56248", "12587", "Winston", "Davidson", "WalMart", "04/29/2022", 2, "NULL"),
                new Prescription("J9060", "Cisplatin", "Plantinal AQ", "Injection, powder or solution per 10mgs", "13496", "25886", "Gregory", "House", "Two Rivers", "04/06/2022", 2, "NULL")
                
         );
    
    @Override
    public void initialize(URL url, ResourceBundle rb) 
    {
        //ObservableList<Appointment> appointmentsList = FXCollections.observableArrayList(Assets.patient.getAppointmentsList());
        // bind
        dateColumn.setCellValueFactory(new PropertyValueFactory<>("date"));
        timeStartColumn.setCellValueFactory(new PropertyValueFactory<>("timeStart"));
        doctorNameColumn.setCellValueFactory(new PropertyValueFactory<>("doctorID"));
        notesColumn.setCellValueFactory(new PropertyValueFactory<>("notes"));
        
        prescriptionNameColumn.setCellValueFactory(new PropertyValueFactory<>("prescriptionName"));
        datePrescribedColumn.setCellValueFactory(new PropertyValueFactory<>("datePrescribed"));
        doctorsNotesColumn.setCellValueFactory(new PropertyValueFactory<>("doctorsNotes"));
        
        //load data
        appointmentsTable.setItems(list);
        prescriptionsTable.setItems(list2);
        
    }    
    
    public void homeScreen(ActionEvent event)throws Exception
    {
        root = FXMLLoader.load(getClass().getResource("/javamedical/JavaMedicalFXML.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setTitle("Java Medical");
        stage.setScene(scene);
        stage.show();
    } 
    
    private ObservableList<Appointment> getAppointments()
    {
        ObservableList<Appointment> appointments = FXCollections.observableArrayList();
        Assets.patient.getAppointmentsList().forEach((appointment) -> {
            appointments.add(appointment);
        });
        return appointments;
    }
    
    private ObservableList<Prescription> getPrescriptions()
    {
        ObservableList<Prescription> prescriptions = FXCollections.observableArrayList();
        Assets.patient.getPrescriptionsList().forEach((prescription) -> {
           prescriptions.add(prescription);
        });
        return prescriptions;
    }
}
