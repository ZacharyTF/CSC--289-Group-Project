/* Logan Sines
 * CSC-289-0B01
 * Java Medical Project
 * 3-12-2022
 */

package javamedical;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.Parent;
import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.PasswordField;
import javafx.scene.control.ComboBox;

public class PatientRegistryController implements Initializable 
{
    // Used to run FXML forms
    private Stage stage;
    private Scene scene;
    private Parent root;
    
    // Initializes controller fields in FXML form
    @FXML
    private Label statuslabel;
    @FXML
    private TextField firstname;
    @FXML
    private TextField lastname;
    @FXML
    private TextField username;
    @FXML
    private ComboBox<String> genderComboBox;
    @FXML
    private PasswordField password;
    @FXML
    private PasswordField passwordConfirm;
    @FXML
    private TextField emailAddress;
    @FXML
    private PasswordField ssNumber;
    @FXML
    private TextField phoneNumber;
    @FXML
    private TextField dateOfBirth;
    
    // String to save to database
    private String patientFirstName;
    private String patientLastName;
    private String patientUsername;
    private String patientGender;
    private String setPassword;
    private String confirmPassword;
    private String patientEmail;
    private String patientSSN;
    private String patientPhoneNumber;
    private String patientDOB;
    

    @Override
    public void initialize(URL url, ResourceBundle rb) 
    {
        genderComboBox.getItems().removeAll(genderComboBox.getItems());
        genderComboBox.getItems().addAll("Male", "Female", "Other");
        genderComboBox.getSelectionModel().select("Gender/Sex");
        
    }    
    
    public void patientRegister(ActionEvent event)throws Exception
    {
        // change to save to database
        patientFirstName = firstname.getText();
        patientLastName = lastname.getText();
        patientUsername = username.getText();
        patientGender = genderComboBox.getSelectionModel().getSelectedItem();
        setPassword = password.getText();
        confirmPassword = passwordConfirm.getText();
        patientEmail = emailAddress.getText();
        patientSSN = ssNumber.getText();
        patientPhoneNumber = phoneNumber.getText();
        patientDOB = dateOfBirth.getText();
    }
    
    public void homeScreen(ActionEvent event)throws Exception
    {
        root = FXMLLoader.load(getClass().getResource("/javamedical/JavaMedicalFXML.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setTitle("Java Medical");
        stage.setScene(scene);
        stage.show();
    } 
}

// statuslabel.setText("ERROR: Patient Registry Incomplete");